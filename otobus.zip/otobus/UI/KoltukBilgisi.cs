﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UI
{
    public class KoltukBilgisi
    {
        public string AD { get; set; }
        public int KoltukNumarasi { get; set; }
        public bool Cinsiyet { get; set; }
        public Button SecilenKoltukAdi { get; set; }
        public decimal Sayac { get; set; }

    }
}
