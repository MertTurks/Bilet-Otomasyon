﻿namespace UI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox61 = new System.Windows.Forms.PictureBox();
            this.pictureBox60 = new System.Windows.Forms.PictureBox();
            this.pictureBox59 = new System.Windows.Forms.PictureBox();
            this.pictureBox58 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi46 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi54 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi50 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi45 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi53 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi49 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi26 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi30 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi32 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi34 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi42 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi38 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi25 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi29 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi31 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi33 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi41 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi37 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi2 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi6 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi10 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi14 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi22 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi18 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi1 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi5 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi9 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi13 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi21 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi17 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi36 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi40 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi44 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi48 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi56 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi52 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi35 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi39 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi43 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi47 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi55 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi51 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi15 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi19 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi23 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi27 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi3 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi7 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi11 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi4 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi8 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi12 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi16 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi20 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi28 = new System.Windows.Forms.PictureBox();
            this.pbEkonomi24 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox61)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox60)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox59)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox58)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi54)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi50)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi45)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi53)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi49)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi41)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi37)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi56)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi52)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi35)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi39)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi43)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi47)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi55)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi51)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(124, 293);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(14, 15);
            this.label1.TabIndex = 73;
            this.label1.Text = "1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(124, 248);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(14, 15);
            this.label2.TabIndex = 75;
            this.label2.Text = "2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(124, 157);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(14, 15);
            this.label3.TabIndex = 76;
            this.label3.Text = "3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(124, 113);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(14, 15);
            this.label4.TabIndex = 77;
            this.label4.Text = "4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(166, 113);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(14, 15);
            this.label5.TabIndex = 81;
            this.label5.Text = "8";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(166, 157);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(14, 15);
            this.label6.TabIndex = 80;
            this.label6.Text = "7";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(166, 248);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(14, 15);
            this.label7.TabIndex = 79;
            this.label7.Text = "6";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(166, 293);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(14, 15);
            this.label8.TabIndex = 78;
            this.label8.Text = "5";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.Location = new System.Drawing.Point(203, 113);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(21, 15);
            this.label9.TabIndex = 85;
            this.label9.Text = "12";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.Location = new System.Drawing.Point(203, 157);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(21, 15);
            this.label10.TabIndex = 84;
            this.label10.Text = "11";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.Location = new System.Drawing.Point(207, 248);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(21, 15);
            this.label11.TabIndex = 83;
            this.label11.Text = "10";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.Location = new System.Drawing.Point(207, 293);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(14, 15);
            this.label12.TabIndex = 82;
            this.label12.Text = "9";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.Location = new System.Drawing.Point(244, 113);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(21, 15);
            this.label13.TabIndex = 89;
            this.label13.Text = "16";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.Location = new System.Drawing.Point(244, 157);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(21, 15);
            this.label14.TabIndex = 88;
            this.label14.Text = "15";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label15.Location = new System.Drawing.Point(242, 248);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(21, 15);
            this.label15.TabIndex = 87;
            this.label15.Text = "14";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label16.Location = new System.Drawing.Point(244, 293);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(21, 15);
            this.label16.TabIndex = 86;
            this.label16.Text = "13";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label17.Location = new System.Drawing.Point(721, 114);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(21, 15);
            this.label17.TabIndex = 105;
            this.label17.Text = "56";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label18.Location = new System.Drawing.Point(721, 158);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(21, 15);
            this.label18.TabIndex = 104;
            this.label18.Text = "55";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label19.Location = new System.Drawing.Point(721, 248);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(21, 15);
            this.label19.TabIndex = 103;
            this.label19.Text = "54";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label20.Location = new System.Drawing.Point(721, 293);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(21, 15);
            this.label20.TabIndex = 102;
            this.label20.Text = "53";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label21.Location = new System.Drawing.Point(680, 114);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(21, 15);
            this.label21.TabIndex = 101;
            this.label21.Text = "52";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label22.Location = new System.Drawing.Point(680, 158);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(21, 15);
            this.label22.TabIndex = 100;
            this.label22.Text = "51";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label23.Location = new System.Drawing.Point(680, 248);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(21, 15);
            this.label23.TabIndex = 99;
            this.label23.Text = "50";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label24.Location = new System.Drawing.Point(680, 293);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(21, 15);
            this.label24.TabIndex = 98;
            this.label24.Text = "49";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label25.Location = new System.Drawing.Point(639, 114);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(21, 15);
            this.label25.TabIndex = 97;
            this.label25.Text = "48";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.Transparent;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label26.Location = new System.Drawing.Point(639, 158);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(21, 15);
            this.label26.TabIndex = 96;
            this.label26.Text = "47";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.Transparent;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label27.Location = new System.Drawing.Point(639, 248);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(21, 15);
            this.label27.TabIndex = 95;
            this.label27.Text = "46";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.Transparent;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label28.Location = new System.Drawing.Point(639, 293);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(21, 15);
            this.label28.TabIndex = 94;
            this.label28.Text = "45";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.Transparent;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label29.Location = new System.Drawing.Point(597, 114);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(21, 15);
            this.label29.TabIndex = 93;
            this.label29.Text = "44";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.Transparent;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label30.Location = new System.Drawing.Point(597, 158);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(21, 15);
            this.label30.TabIndex = 92;
            this.label30.Text = "43";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.Transparent;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label31.Location = new System.Drawing.Point(597, 248);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(21, 15);
            this.label31.TabIndex = 91;
            this.label31.Text = "42";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.Transparent;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label32.Location = new System.Drawing.Point(597, 293);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(21, 15);
            this.label32.TabIndex = 90;
            this.label32.Text = "41";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.Color.Transparent;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label33.Location = new System.Drawing.Point(556, 248);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(21, 15);
            this.label33.TabIndex = 113;
            this.label33.Text = "38";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.Color.Transparent;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label34.Location = new System.Drawing.Point(556, 293);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(21, 15);
            this.label34.TabIndex = 112;
            this.label34.Text = "37";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.BackColor = System.Drawing.Color.Transparent;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label35.Location = new System.Drawing.Point(517, 248);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(21, 15);
            this.label35.TabIndex = 111;
            this.label35.Text = "34";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.Transparent;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label36.Location = new System.Drawing.Point(517, 293);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(21, 15);
            this.label36.TabIndex = 110;
            this.label36.Text = "33";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.Color.Transparent;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label37.Location = new System.Drawing.Point(471, 248);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(21, 15);
            this.label37.TabIndex = 109;
            this.label37.Text = "32";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.Color.Transparent;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label38.Location = new System.Drawing.Point(470, 293);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(21, 15);
            this.label38.TabIndex = 108;
            this.label38.Text = "31";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.Color.Transparent;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label39.Location = new System.Drawing.Point(419, 248);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(21, 15);
            this.label39.TabIndex = 107;
            this.label39.Text = "30";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.Color.Transparent;
            this.label40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label40.Location = new System.Drawing.Point(418, 293);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(21, 15);
            this.label40.TabIndex = 106;
            this.label40.Text = "29";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.Color.Transparent;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label41.Location = new System.Drawing.Point(285, 113);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(21, 15);
            this.label41.TabIndex = 117;
            this.label41.Text = "20";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.Transparent;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label42.Location = new System.Drawing.Point(285, 157);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(21, 15);
            this.label42.TabIndex = 116;
            this.label42.Text = "19";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.Transparent;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label43.Location = new System.Drawing.Point(285, 248);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(21, 15);
            this.label43.TabIndex = 115;
            this.label43.Text = "18";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.BackColor = System.Drawing.Color.Transparent;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label44.Location = new System.Drawing.Point(285, 293);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(21, 15);
            this.label44.TabIndex = 114;
            this.label44.Text = "17";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.BackColor = System.Drawing.Color.Transparent;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label45.Location = new System.Drawing.Point(326, 113);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(21, 15);
            this.label45.TabIndex = 121;
            this.label45.Text = "24";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.BackColor = System.Drawing.Color.Transparent;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label46.Location = new System.Drawing.Point(326, 157);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(21, 15);
            this.label46.TabIndex = 120;
            this.label46.Text = "23";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.BackColor = System.Drawing.Color.Transparent;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label47.Location = new System.Drawing.Point(326, 248);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(21, 15);
            this.label47.TabIndex = 119;
            this.label47.Text = "22";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.BackColor = System.Drawing.Color.Transparent;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label48.Location = new System.Drawing.Point(326, 293);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(21, 15);
            this.label48.TabIndex = 118;
            this.label48.Text = "21";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.BackColor = System.Drawing.Color.Transparent;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label49.Location = new System.Drawing.Point(369, 113);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(21, 15);
            this.label49.TabIndex = 125;
            this.label49.Text = "28";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.BackColor = System.Drawing.Color.Transparent;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label50.Location = new System.Drawing.Point(369, 157);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(21, 15);
            this.label50.TabIndex = 124;
            this.label50.Text = "27";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.BackColor = System.Drawing.Color.Transparent;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label51.Location = new System.Drawing.Point(369, 248);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(21, 15);
            this.label51.TabIndex = 123;
            this.label51.Text = "26";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.BackColor = System.Drawing.Color.Transparent;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label52.Location = new System.Drawing.Point(369, 293);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(21, 15);
            this.label52.TabIndex = 122;
            this.label52.Text = "25";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.BackColor = System.Drawing.Color.Transparent;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label53.Location = new System.Drawing.Point(517, 113);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(21, 15);
            this.label53.TabIndex = 127;
            this.label53.Text = "36";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.BackColor = System.Drawing.Color.Transparent;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label54.Location = new System.Drawing.Point(517, 158);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(21, 15);
            this.label54.TabIndex = 126;
            this.label54.Text = "35";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.BackColor = System.Drawing.Color.Transparent;
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label55.Location = new System.Drawing.Point(557, 114);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(21, 15);
            this.label55.TabIndex = 128;
            this.label55.Text = "40";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.BackColor = System.Drawing.Color.Transparent;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label56.Location = new System.Drawing.Point(557, 157);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(21, 15);
            this.label56.TabIndex = 129;
            this.label56.Text = "39";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.BackColor = System.Drawing.Color.Transparent;
            this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label57.Location = new System.Drawing.Point(151, 381);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(41, 22);
            this.label57.TabIndex = 130;
            this.label57.Text = "Boş";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.BackColor = System.Drawing.Color.Transparent;
            this.label58.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label58.Location = new System.Drawing.Point(263, 381);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(56, 22);
            this.label58.TabIndex = 131;
            this.label58.Text = "Erkek";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.BackColor = System.Drawing.Color.Transparent;
            this.label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label59.Location = new System.Drawing.Point(388, 381);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(56, 22);
            this.label59.TabIndex = 132;
            this.label59.Text = "Kadın";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.BackColor = System.Drawing.Color.Transparent;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label60.Location = new System.Drawing.Point(517, 381);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(76, 22);
            this.label60.TabIndex = 133;
            this.label60.Text = "Rezerve";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.BackColor = System.Drawing.Color.Transparent;
            this.label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label61.Location = new System.Drawing.Point(657, 381);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(53, 22);
            this.label61.TabIndex = 135;
            this.label61.Text = "Seçili";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::UI.Properties.Resources.secilikoltuk;
            this.pictureBox2.Location = new System.Drawing.Point(616, 375);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(35, 35);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 134;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox61
            // 
            this.pictureBox61.Image = global::UI.Properties.Resources.koltukrezerv;
            this.pictureBox61.Location = new System.Drawing.Point(476, 375);
            this.pictureBox61.Name = "pictureBox61";
            this.pictureBox61.Size = new System.Drawing.Size(35, 35);
            this.pictureBox61.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox61.TabIndex = 72;
            this.pictureBox61.TabStop = false;
            // 
            // pictureBox60
            // 
            this.pictureBox60.Image = global::UI.Properties.Resources.koltukerkek;
            this.pictureBox60.Location = new System.Drawing.Point(222, 375);
            this.pictureBox60.Name = "pictureBox60";
            this.pictureBox60.Size = new System.Drawing.Size(35, 35);
            this.pictureBox60.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox60.TabIndex = 71;
            this.pictureBox60.TabStop = false;
            // 
            // pictureBox59
            // 
            this.pictureBox59.Image = global::UI.Properties.Resources.koltukkadin;
            this.pictureBox59.Location = new System.Drawing.Point(347, 375);
            this.pictureBox59.Name = "pictureBox59";
            this.pictureBox59.Size = new System.Drawing.Size(35, 35);
            this.pictureBox59.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox59.TabIndex = 70;
            this.pictureBox59.TabStop = false;
            // 
            // pictureBox58
            // 
            this.pictureBox58.Image = global::UI.Properties.Resources.koltukson4;
            this.pictureBox58.Location = new System.Drawing.Point(103, 375);
            this.pictureBox58.Name = "pictureBox58";
            this.pictureBox58.Size = new System.Drawing.Size(35, 35);
            this.pictureBox58.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox58.TabIndex = 69;
            this.pictureBox58.TabStop = false;
            // 
            // pbEkonomi46
            // 
            this.pbEkonomi46.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi46.Location = new System.Drawing.Point(633, 239);
            this.pbEkonomi46.Name = "pbEkonomi46";
            this.pbEkonomi46.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi46.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi46.TabIndex = 68;
            this.pbEkonomi46.TabStop = false;
            // 
            // pbEkonomi54
            // 
            this.pbEkonomi54.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi54.Location = new System.Drawing.Point(715, 239);
            this.pbEkonomi54.Name = "pbEkonomi54";
            this.pbEkonomi54.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi54.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi54.TabIndex = 67;
            this.pbEkonomi54.TabStop = false;
            // 
            // pbEkonomi50
            // 
            this.pbEkonomi50.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi50.Location = new System.Drawing.Point(674, 239);
            this.pbEkonomi50.Name = "pbEkonomi50";
            this.pbEkonomi50.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi50.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi50.TabIndex = 66;
            this.pbEkonomi50.TabStop = false;
            // 
            // pbEkonomi45
            // 
            this.pbEkonomi45.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi45.Location = new System.Drawing.Point(633, 283);
            this.pbEkonomi45.Name = "pbEkonomi45";
            this.pbEkonomi45.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi45.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi45.TabIndex = 65;
            this.pbEkonomi45.TabStop = false;
            // 
            // pbEkonomi53
            // 
            this.pbEkonomi53.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi53.Location = new System.Drawing.Point(715, 283);
            this.pbEkonomi53.Name = "pbEkonomi53";
            this.pbEkonomi53.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi53.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi53.TabIndex = 64;
            this.pbEkonomi53.TabStop = false;
            // 
            // pbEkonomi49
            // 
            this.pbEkonomi49.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi49.Location = new System.Drawing.Point(674, 283);
            this.pbEkonomi49.Name = "pbEkonomi49";
            this.pbEkonomi49.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi49.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi49.TabIndex = 63;
            this.pbEkonomi49.TabStop = false;
            // 
            // pbEkonomi26
            // 
            this.pbEkonomi26.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi26.Location = new System.Drawing.Point(364, 239);
            this.pbEkonomi26.Name = "pbEkonomi26";
            this.pbEkonomi26.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi26.TabIndex = 62;
            this.pbEkonomi26.TabStop = false;
            // 
            // pbEkonomi30
            // 
            this.pbEkonomi30.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi30.Location = new System.Drawing.Point(413, 239);
            this.pbEkonomi30.Name = "pbEkonomi30";
            this.pbEkonomi30.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi30.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi30.TabIndex = 61;
            this.pbEkonomi30.TabStop = false;
            // 
            // pbEkonomi32
            // 
            this.pbEkonomi32.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi32.Location = new System.Drawing.Point(465, 239);
            this.pbEkonomi32.Name = "pbEkonomi32";
            this.pbEkonomi32.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi32.TabIndex = 60;
            this.pbEkonomi32.TabStop = false;
            // 
            // pbEkonomi34
            // 
            this.pbEkonomi34.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi34.Location = new System.Drawing.Point(510, 239);
            this.pbEkonomi34.Name = "pbEkonomi34";
            this.pbEkonomi34.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi34.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi34.TabIndex = 59;
            this.pbEkonomi34.TabStop = false;
            // 
            // pbEkonomi42
            // 
            this.pbEkonomi42.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi42.Location = new System.Drawing.Point(592, 239);
            this.pbEkonomi42.Name = "pbEkonomi42";
            this.pbEkonomi42.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi42.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi42.TabIndex = 58;
            this.pbEkonomi42.TabStop = false;
            // 
            // pbEkonomi38
            // 
            this.pbEkonomi38.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi38.Location = new System.Drawing.Point(551, 239);
            this.pbEkonomi38.Name = "pbEkonomi38";
            this.pbEkonomi38.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi38.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi38.TabIndex = 57;
            this.pbEkonomi38.TabStop = false;
            // 
            // pbEkonomi25
            // 
            this.pbEkonomi25.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi25.Location = new System.Drawing.Point(364, 283);
            this.pbEkonomi25.Name = "pbEkonomi25";
            this.pbEkonomi25.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi25.TabIndex = 56;
            this.pbEkonomi25.TabStop = false;
            // 
            // pbEkonomi29
            // 
            this.pbEkonomi29.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi29.Location = new System.Drawing.Point(413, 283);
            this.pbEkonomi29.Name = "pbEkonomi29";
            this.pbEkonomi29.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi29.TabIndex = 55;
            this.pbEkonomi29.TabStop = false;
            // 
            // pbEkonomi31
            // 
            this.pbEkonomi31.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi31.Location = new System.Drawing.Point(465, 283);
            this.pbEkonomi31.Name = "pbEkonomi31";
            this.pbEkonomi31.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi31.TabIndex = 54;
            this.pbEkonomi31.TabStop = false;
            // 
            // pbEkonomi33
            // 
            this.pbEkonomi33.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi33.Location = new System.Drawing.Point(510, 283);
            this.pbEkonomi33.Name = "pbEkonomi33";
            this.pbEkonomi33.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi33.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi33.TabIndex = 53;
            this.pbEkonomi33.TabStop = false;
            // 
            // pbEkonomi41
            // 
            this.pbEkonomi41.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi41.Location = new System.Drawing.Point(592, 283);
            this.pbEkonomi41.Name = "pbEkonomi41";
            this.pbEkonomi41.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi41.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi41.TabIndex = 52;
            this.pbEkonomi41.TabStop = false;
            // 
            // pbEkonomi37
            // 
            this.pbEkonomi37.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi37.Location = new System.Drawing.Point(551, 283);
            this.pbEkonomi37.Name = "pbEkonomi37";
            this.pbEkonomi37.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi37.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi37.TabIndex = 51;
            this.pbEkonomi37.TabStop = false;
            // 
            // pbEkonomi2
            // 
            this.pbEkonomi2.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi2.Location = new System.Drawing.Point(115, 239);
            this.pbEkonomi2.Name = "pbEkonomi2";
            this.pbEkonomi2.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi2.TabIndex = 50;
            this.pbEkonomi2.TabStop = false;
            // 
            // pbEkonomi6
            // 
            this.pbEkonomi6.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi6.Location = new System.Drawing.Point(156, 239);
            this.pbEkonomi6.Name = "pbEkonomi6";
            this.pbEkonomi6.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi6.TabIndex = 49;
            this.pbEkonomi6.TabStop = false;
            // 
            // pbEkonomi10
            // 
            this.pbEkonomi10.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi10.Location = new System.Drawing.Point(197, 239);
            this.pbEkonomi10.Name = "pbEkonomi10";
            this.pbEkonomi10.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi10.TabIndex = 48;
            this.pbEkonomi10.TabStop = false;
            // 
            // pbEkonomi14
            // 
            this.pbEkonomi14.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi14.Location = new System.Drawing.Point(238, 239);
            this.pbEkonomi14.Name = "pbEkonomi14";
            this.pbEkonomi14.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi14.TabIndex = 47;
            this.pbEkonomi14.TabStop = false;
            // 
            // pbEkonomi22
            // 
            this.pbEkonomi22.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi22.Location = new System.Drawing.Point(320, 239);
            this.pbEkonomi22.Name = "pbEkonomi22";
            this.pbEkonomi22.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi22.TabIndex = 46;
            this.pbEkonomi22.TabStop = false;
            // 
            // pbEkonomi18
            // 
            this.pbEkonomi18.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi18.Location = new System.Drawing.Point(279, 239);
            this.pbEkonomi18.Name = "pbEkonomi18";
            this.pbEkonomi18.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi18.TabIndex = 45;
            this.pbEkonomi18.TabStop = false;
            // 
            // pbEkonomi1
            // 
            this.pbEkonomi1.BackColor = System.Drawing.Color.White;
            this.pbEkonomi1.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi1.Location = new System.Drawing.Point(115, 283);
            this.pbEkonomi1.Name = "pbEkonomi1";
            this.pbEkonomi1.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi1.TabIndex = 44;
            this.pbEkonomi1.TabStop = false;
            // 
            // pbEkonomi5
            // 
            this.pbEkonomi5.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi5.Location = new System.Drawing.Point(156, 283);
            this.pbEkonomi5.Name = "pbEkonomi5";
            this.pbEkonomi5.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi5.TabIndex = 43;
            this.pbEkonomi5.TabStop = false;
            // 
            // pbEkonomi9
            // 
            this.pbEkonomi9.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi9.Location = new System.Drawing.Point(197, 283);
            this.pbEkonomi9.Name = "pbEkonomi9";
            this.pbEkonomi9.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi9.TabIndex = 42;
            this.pbEkonomi9.TabStop = false;
            // 
            // pbEkonomi13
            // 
            this.pbEkonomi13.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi13.Location = new System.Drawing.Point(238, 283);
            this.pbEkonomi13.Name = "pbEkonomi13";
            this.pbEkonomi13.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi13.TabIndex = 41;
            this.pbEkonomi13.TabStop = false;
            // 
            // pbEkonomi21
            // 
            this.pbEkonomi21.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi21.Location = new System.Drawing.Point(320, 283);
            this.pbEkonomi21.Name = "pbEkonomi21";
            this.pbEkonomi21.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi21.TabIndex = 40;
            this.pbEkonomi21.TabStop = false;
            // 
            // pbEkonomi17
            // 
            this.pbEkonomi17.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi17.Location = new System.Drawing.Point(279, 283);
            this.pbEkonomi17.Name = "pbEkonomi17";
            this.pbEkonomi17.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi17.TabIndex = 39;
            this.pbEkonomi17.TabStop = false;
            // 
            // pbEkonomi36
            // 
            this.pbEkonomi36.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi36.Location = new System.Drawing.Point(510, 104);
            this.pbEkonomi36.Name = "pbEkonomi36";
            this.pbEkonomi36.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi36.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi36.TabIndex = 38;
            this.pbEkonomi36.TabStop = false;
            // 
            // pbEkonomi40
            // 
            this.pbEkonomi40.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi40.Location = new System.Drawing.Point(551, 104);
            this.pbEkonomi40.Name = "pbEkonomi40";
            this.pbEkonomi40.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi40.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi40.TabIndex = 37;
            this.pbEkonomi40.TabStop = false;
            // 
            // pbEkonomi44
            // 
            this.pbEkonomi44.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi44.Location = new System.Drawing.Point(592, 104);
            this.pbEkonomi44.Name = "pbEkonomi44";
            this.pbEkonomi44.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi44.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi44.TabIndex = 36;
            this.pbEkonomi44.TabStop = false;
            // 
            // pbEkonomi48
            // 
            this.pbEkonomi48.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi48.Location = new System.Drawing.Point(633, 104);
            this.pbEkonomi48.Name = "pbEkonomi48";
            this.pbEkonomi48.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi48.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi48.TabIndex = 35;
            this.pbEkonomi48.TabStop = false;
            // 
            // pbEkonomi56
            // 
            this.pbEkonomi56.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi56.Location = new System.Drawing.Point(715, 104);
            this.pbEkonomi56.Name = "pbEkonomi56";
            this.pbEkonomi56.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi56.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi56.TabIndex = 34;
            this.pbEkonomi56.TabStop = false;
            // 
            // pbEkonomi52
            // 
            this.pbEkonomi52.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi52.Location = new System.Drawing.Point(674, 104);
            this.pbEkonomi52.Name = "pbEkonomi52";
            this.pbEkonomi52.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi52.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi52.TabIndex = 33;
            this.pbEkonomi52.TabStop = false;
            // 
            // pbEkonomi35
            // 
            this.pbEkonomi35.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi35.Location = new System.Drawing.Point(510, 148);
            this.pbEkonomi35.Name = "pbEkonomi35";
            this.pbEkonomi35.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi35.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi35.TabIndex = 32;
            this.pbEkonomi35.TabStop = false;
            // 
            // pbEkonomi39
            // 
            this.pbEkonomi39.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi39.Location = new System.Drawing.Point(551, 148);
            this.pbEkonomi39.Name = "pbEkonomi39";
            this.pbEkonomi39.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi39.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi39.TabIndex = 31;
            this.pbEkonomi39.TabStop = false;
            // 
            // pbEkonomi43
            // 
            this.pbEkonomi43.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi43.Location = new System.Drawing.Point(592, 148);
            this.pbEkonomi43.Name = "pbEkonomi43";
            this.pbEkonomi43.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi43.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi43.TabIndex = 30;
            this.pbEkonomi43.TabStop = false;
            // 
            // pbEkonomi47
            // 
            this.pbEkonomi47.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi47.Location = new System.Drawing.Point(633, 148);
            this.pbEkonomi47.Name = "pbEkonomi47";
            this.pbEkonomi47.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi47.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi47.TabIndex = 29;
            this.pbEkonomi47.TabStop = false;
            // 
            // pbEkonomi55
            // 
            this.pbEkonomi55.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi55.Location = new System.Drawing.Point(715, 148);
            this.pbEkonomi55.Name = "pbEkonomi55";
            this.pbEkonomi55.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi55.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi55.TabIndex = 28;
            this.pbEkonomi55.TabStop = false;
            // 
            // pbEkonomi51
            // 
            this.pbEkonomi51.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi51.Location = new System.Drawing.Point(674, 148);
            this.pbEkonomi51.Name = "pbEkonomi51";
            this.pbEkonomi51.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi51.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi51.TabIndex = 27;
            this.pbEkonomi51.TabStop = false;
            // 
            // pbEkonomi15
            // 
            this.pbEkonomi15.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi15.Location = new System.Drawing.Point(238, 148);
            this.pbEkonomi15.Name = "pbEkonomi15";
            this.pbEkonomi15.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi15.TabIndex = 26;
            this.pbEkonomi15.TabStop = false;
            // 
            // pbEkonomi19
            // 
            this.pbEkonomi19.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi19.Location = new System.Drawing.Point(279, 148);
            this.pbEkonomi19.Name = "pbEkonomi19";
            this.pbEkonomi19.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi19.TabIndex = 25;
            this.pbEkonomi19.TabStop = false;
            // 
            // pbEkonomi23
            // 
            this.pbEkonomi23.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi23.Location = new System.Drawing.Point(320, 148);
            this.pbEkonomi23.Name = "pbEkonomi23";
            this.pbEkonomi23.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi23.TabIndex = 24;
            this.pbEkonomi23.TabStop = false;
            // 
            // pbEkonomi27
            // 
            this.pbEkonomi27.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi27.Location = new System.Drawing.Point(361, 148);
            this.pbEkonomi27.Name = "pbEkonomi27";
            this.pbEkonomi27.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi27.TabIndex = 23;
            this.pbEkonomi27.TabStop = false;
            // 
            // pbEkonomi3
            // 
            this.pbEkonomi3.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi3.Location = new System.Drawing.Point(115, 148);
            this.pbEkonomi3.Name = "pbEkonomi3";
            this.pbEkonomi3.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi3.TabIndex = 22;
            this.pbEkonomi3.TabStop = false;
            // 
            // pbEkonomi7
            // 
            this.pbEkonomi7.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi7.Location = new System.Drawing.Point(156, 148);
            this.pbEkonomi7.Name = "pbEkonomi7";
            this.pbEkonomi7.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi7.TabIndex = 21;
            this.pbEkonomi7.TabStop = false;
            // 
            // pbEkonomi11
            // 
            this.pbEkonomi11.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi11.Location = new System.Drawing.Point(197, 148);
            this.pbEkonomi11.Name = "pbEkonomi11";
            this.pbEkonomi11.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi11.TabIndex = 20;
            this.pbEkonomi11.TabStop = false;
            // 
            // pbEkonomi4
            // 
            this.pbEkonomi4.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi4.Location = new System.Drawing.Point(115, 104);
            this.pbEkonomi4.Name = "pbEkonomi4";
            this.pbEkonomi4.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi4.TabIndex = 19;
            this.pbEkonomi4.TabStop = false;
            // 
            // pbEkonomi8
            // 
            this.pbEkonomi8.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi8.Location = new System.Drawing.Point(156, 104);
            this.pbEkonomi8.Name = "pbEkonomi8";
            this.pbEkonomi8.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi8.TabIndex = 18;
            this.pbEkonomi8.TabStop = false;
            // 
            // pbEkonomi12
            // 
            this.pbEkonomi12.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi12.Location = new System.Drawing.Point(197, 104);
            this.pbEkonomi12.Name = "pbEkonomi12";
            this.pbEkonomi12.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi12.TabIndex = 17;
            this.pbEkonomi12.TabStop = false;
            // 
            // pbEkonomi16
            // 
            this.pbEkonomi16.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi16.Location = new System.Drawing.Point(238, 104);
            this.pbEkonomi16.Name = "pbEkonomi16";
            this.pbEkonomi16.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi16.TabIndex = 16;
            this.pbEkonomi16.TabStop = false;
            // 
            // pbEkonomi20
            // 
            this.pbEkonomi20.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi20.Location = new System.Drawing.Point(279, 104);
            this.pbEkonomi20.Name = "pbEkonomi20";
            this.pbEkonomi20.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi20.TabIndex = 15;
            this.pbEkonomi20.TabStop = false;
            // 
            // pbEkonomi28
            // 
            this.pbEkonomi28.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi28.Location = new System.Drawing.Point(361, 104);
            this.pbEkonomi28.Name = "pbEkonomi28";
            this.pbEkonomi28.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi28.TabIndex = 14;
            this.pbEkonomi28.TabStop = false;
            // 
            // pbEkonomi24
            // 
            this.pbEkonomi24.Image = global::UI.Properties.Resources.koltukson4;
            this.pbEkonomi24.Location = new System.Drawing.Point(320, 104);
            this.pbEkonomi24.Name = "pbEkonomi24";
            this.pbEkonomi24.Size = new System.Drawing.Size(35, 35);
            this.pbEkonomi24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbEkonomi24.TabIndex = 13;
            this.pbEkonomi24.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::UI.Properties.Resources.koltuksemasi2;
            this.pictureBox1.Location = new System.Drawing.Point(12, 74);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(800, 274);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(814, 473);
            this.Controls.Add(this.label61);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.label60);
            this.Controls.Add(this.label59);
            this.Controls.Add(this.label58);
            this.Controls.Add(this.label57);
            this.Controls.Add(this.label56);
            this.Controls.Add(this.label55);
            this.Controls.Add(this.label53);
            this.Controls.Add(this.label54);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label47);
            this.Controls.Add(this.label48);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label43);
            this.Controls.Add(this.label44);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox61);
            this.Controls.Add(this.pictureBox60);
            this.Controls.Add(this.pictureBox59);
            this.Controls.Add(this.pictureBox58);
            this.Controls.Add(this.pbEkonomi46);
            this.Controls.Add(this.pbEkonomi54);
            this.Controls.Add(this.pbEkonomi50);
            this.Controls.Add(this.pbEkonomi45);
            this.Controls.Add(this.pbEkonomi53);
            this.Controls.Add(this.pbEkonomi49);
            this.Controls.Add(this.pbEkonomi26);
            this.Controls.Add(this.pbEkonomi30);
            this.Controls.Add(this.pbEkonomi32);
            this.Controls.Add(this.pbEkonomi34);
            this.Controls.Add(this.pbEkonomi42);
            this.Controls.Add(this.pbEkonomi38);
            this.Controls.Add(this.pbEkonomi25);
            this.Controls.Add(this.pbEkonomi29);
            this.Controls.Add(this.pbEkonomi31);
            this.Controls.Add(this.pbEkonomi33);
            this.Controls.Add(this.pbEkonomi41);
            this.Controls.Add(this.pbEkonomi37);
            this.Controls.Add(this.pbEkonomi2);
            this.Controls.Add(this.pbEkonomi6);
            this.Controls.Add(this.pbEkonomi10);
            this.Controls.Add(this.pbEkonomi14);
            this.Controls.Add(this.pbEkonomi22);
            this.Controls.Add(this.pbEkonomi18);
            this.Controls.Add(this.pbEkonomi1);
            this.Controls.Add(this.pbEkonomi5);
            this.Controls.Add(this.pbEkonomi9);
            this.Controls.Add(this.pbEkonomi13);
            this.Controls.Add(this.pbEkonomi21);
            this.Controls.Add(this.pbEkonomi17);
            this.Controls.Add(this.pbEkonomi36);
            this.Controls.Add(this.pbEkonomi40);
            this.Controls.Add(this.pbEkonomi44);
            this.Controls.Add(this.pbEkonomi48);
            this.Controls.Add(this.pbEkonomi56);
            this.Controls.Add(this.pbEkonomi52);
            this.Controls.Add(this.pbEkonomi35);
            this.Controls.Add(this.pbEkonomi39);
            this.Controls.Add(this.pbEkonomi43);
            this.Controls.Add(this.pbEkonomi47);
            this.Controls.Add(this.pbEkonomi55);
            this.Controls.Add(this.pbEkonomi51);
            this.Controls.Add(this.pbEkonomi15);
            this.Controls.Add(this.pbEkonomi19);
            this.Controls.Add(this.pbEkonomi23);
            this.Controls.Add(this.pbEkonomi27);
            this.Controls.Add(this.pbEkonomi3);
            this.Controls.Add(this.pbEkonomi7);
            this.Controls.Add(this.pbEkonomi11);
            this.Controls.Add(this.pbEkonomi4);
            this.Controls.Add(this.pbEkonomi8);
            this.Controls.Add(this.pbEkonomi12);
            this.Controls.Add(this.pbEkonomi16);
            this.Controls.Add(this.pbEkonomi20);
            this.Controls.Add(this.pbEkonomi28);
            this.Controls.Add(this.pbEkonomi24);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox61)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox60)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox59)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox58)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi54)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi50)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi45)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi53)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi49)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi41)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi37)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi56)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi52)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi35)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi39)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi43)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi47)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi55)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi51)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEkonomi24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbEkonomi28;
        private System.Windows.Forms.PictureBox pbEkonomi24;
        private System.Windows.Forms.PictureBox pbEkonomi20;
        private System.Windows.Forms.PictureBox pbEkonomi16;
        private System.Windows.Forms.PictureBox pbEkonomi12;
        private System.Windows.Forms.PictureBox pbEkonomi8;
        private System.Windows.Forms.PictureBox pbEkonomi4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pbEkonomi3;
        private System.Windows.Forms.PictureBox pbEkonomi7;
        private System.Windows.Forms.PictureBox pbEkonomi11;
        private System.Windows.Forms.PictureBox pbEkonomi19;
        private System.Windows.Forms.PictureBox pbEkonomi23;
        private System.Windows.Forms.PictureBox pbEkonomi27;
        private System.Windows.Forms.PictureBox pbEkonomi15;
        private System.Windows.Forms.PictureBox pbEkonomi35;
        private System.Windows.Forms.PictureBox pbEkonomi39;
        private System.Windows.Forms.PictureBox pbEkonomi43;
        private System.Windows.Forms.PictureBox pbEkonomi47;
        private System.Windows.Forms.PictureBox pbEkonomi55;
        private System.Windows.Forms.PictureBox pbEkonomi51;
        private System.Windows.Forms.PictureBox pbEkonomi36;
        private System.Windows.Forms.PictureBox pbEkonomi40;
        private System.Windows.Forms.PictureBox pbEkonomi44;
        private System.Windows.Forms.PictureBox pbEkonomi48;
        private System.Windows.Forms.PictureBox pbEkonomi56;
        private System.Windows.Forms.PictureBox pbEkonomi52;
        private System.Windows.Forms.PictureBox pbEkonomi2;
        private System.Windows.Forms.PictureBox pbEkonomi6;
        private System.Windows.Forms.PictureBox pbEkonomi10;
        private System.Windows.Forms.PictureBox pbEkonomi14;
        private System.Windows.Forms.PictureBox pbEkonomi22;
        private System.Windows.Forms.PictureBox pbEkonomi18;
        private System.Windows.Forms.PictureBox pbEkonomi1;
        private System.Windows.Forms.PictureBox pbEkonomi5;
        private System.Windows.Forms.PictureBox pbEkonomi9;
        private System.Windows.Forms.PictureBox pbEkonomi13;
        private System.Windows.Forms.PictureBox pbEkonomi21;
        private System.Windows.Forms.PictureBox pbEkonomi17;
        private System.Windows.Forms.PictureBox pbEkonomi26;
        private System.Windows.Forms.PictureBox pbEkonomi30;
        private System.Windows.Forms.PictureBox pbEkonomi32;
        private System.Windows.Forms.PictureBox pbEkonomi34;
        private System.Windows.Forms.PictureBox pbEkonomi42;
        private System.Windows.Forms.PictureBox pbEkonomi38;
        private System.Windows.Forms.PictureBox pbEkonomi25;
        private System.Windows.Forms.PictureBox pbEkonomi29;
        private System.Windows.Forms.PictureBox pbEkonomi31;
        private System.Windows.Forms.PictureBox pbEkonomi33;
        private System.Windows.Forms.PictureBox pbEkonomi41;
        private System.Windows.Forms.PictureBox pbEkonomi37;
        private System.Windows.Forms.PictureBox pbEkonomi46;
        private System.Windows.Forms.PictureBox pbEkonomi54;
        private System.Windows.Forms.PictureBox pbEkonomi50;
        private System.Windows.Forms.PictureBox pbEkonomi45;
        private System.Windows.Forms.PictureBox pbEkonomi53;
        private System.Windows.Forms.PictureBox pbEkonomi49;
        private System.Windows.Forms.PictureBox pictureBox58;
        private System.Windows.Forms.PictureBox pictureBox59;
        private System.Windows.Forms.PictureBox pictureBox60;
        private System.Windows.Forms.PictureBox pictureBox61;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}